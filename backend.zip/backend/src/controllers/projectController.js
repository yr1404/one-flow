const { validationResult } = require('express-validator');
const { Project } = require('../models');


exports.create = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const {
      name,
      description,
      manager_id,
      start_date,
      deadline,
      status,
      priority,
      budget,
    } = req.body;

    const created = await Project.create({
      name,
      description,
      manager_id,
      start_date,
      deadline,
      status,
      priority,
      budget,
    });

    res.status(201).json(created);
  } catch (err) {
    next(err);
  }
};


exports.list = async (req, res, next) => {
  try {
    const projects = await Project.findAll();
    res.json(projects);
  } catch (err) { next(err); }
};

exports.getById = async (req, res, next) => {
  try {
    const project = await Project.findByPk(req.params.id);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    res.json(project);
  } catch (err) { next(err); }
};

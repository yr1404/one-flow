const express = require('express');
const morgan = require('morgan');
const cors = require('cors');

const authRoutes=require('./routes/auth');
const projectRoutes=require('./routes/projects');

const app = express();

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

const db = require('./config/db'); 

app.get('/health', (req, res) => res.json({ status: 'ok' }));

// DB 
app.get('/db-health', async (req, res) => {
  try {
    const result = await db.query('SELECT 1 AS ok');
    res.json({ db: result.rows[0].ok === 1 });
  } catch (err) {
    console.error('DB health check failed', err);
    res.status(500).json({ db: false, error: err.message });
  }
});

if (authRoutes) app.use('/api/auth', authRoutes);
if (projectRoutes) app.use('/api/projects', projectRoutes);

// 404 handler
app.use((req, res, next) => {
  res.status(404).json({ message: 'Not Found' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ message: err.message || 'Server error' });
});

module.exports = app;